-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 06, 2012 at 09:58 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sunnybeach`
--

-- --------------------------------------------------------

--
-- Table structure for table `tgp_bien`
--

CREATE TABLE IF NOT EXISTS `tgp_bien` (
  `ten` varchar(32) NOT NULL,
  `gia_tri` text NOT NULL,
  PRIMARY KEY (`ten`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tgp_bien`
--

INSERT INTO `tgp_bien` (`ten`, `gia_tri`) VALUES
('email', 'thienbaoit@gmail.com'),
('lien_ket', ''),
('title', 'KhÃ¡ch sáº¡n Edenhotel'),
('het_phong', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tgp_cat`
--

CREATE TABLE IF NOT EXISTS `tgp_cat` (
  `id` varchar(20) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `thu_tu` int(11) NOT NULL DEFAULT '1',
  `_cms` int(1) NOT NULL DEFAULT '0',
  `_product` int(1) DEFAULT '0',
  `_gallery` int(1) NOT NULL DEFAULT '0',
  `_doc` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tgp_cat`
--

INSERT INTO `tgp_cat` (`id`, `ten`, `thu_tu`, `_cms`, `_product`, `_gallery`, `_doc`) VALUES
('gioi_thieu', 'Giá»›i thiá»‡u', 1, 0, 0, 1, 0),
('he_thong_phong', 'Há»‡ thá»‘ng phÃ²ng', 1, 1, 0, 0, 0),
('thu_vien_hinh', 'ThÆ° viá»‡n hÃ¬nh', 1, 0, 0, 1, 0),
('slide_background', 'Slide background', 1, 0, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_cms`
--

CREATE TABLE IF NOT EXISTS `tgp_cms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `chu_thich` text NOT NULL,
  `hinh` varchar(255) DEFAULT 'no',
  `hinh_note` varchar(255) NOT NULL,
  `noi_dung` text NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL DEFAULT '0',
  `luot_xem` int(11) NOT NULL DEFAULT '0',
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `photos` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=181 ;

--
-- Dumping data for table `tgp_cms`
--

INSERT INTO `tgp_cms` (`id`, `cat`, `ten`, `chu_thich`, `hinh`, `hinh_note`, `noi_dung`, `hien_thi`, `time`, `user`, `luot_xem`, `noi_bat`, `photos`) VALUES
(177, 5, 'Superior', 'GÃ­a : 450.000d/ngay - 7phong', '177.jpg', '', 'El Clasico cuá»‘i c&ugrave;ng cá»§a nÄƒm nay,  Ronaldo pháº§n n&agrave;o Ä‘Æ°á»£c Ä‘&aacute;nh gi&aacute;  cao  hÆ¡n sá»‘ 10 cá»§a Barca nhá» phong Ä‘á»™ á»•n  Ä‘á»‹nh trong suá»‘t thá»i gian qua.   Kh&ocirc;ng chá»‰ li&ecirc;n tiáº¿p ná»• s&uacute;ng á»Ÿ nhá»¯ng tráº­n  gáº§n Ä‘&acirc;y gi&uacute;p Real thÄƒng tiáº¿n  m', 1, 1323882000, 1, 0, 0, '177_1286589684.jpg;177_242255738.jpg;177_318576801.jpg;177_177974738.jpg;177_698242777.jpg;177_432230137.jpg'),
(178, 5, 'Standard', 'GÃ­a : 470.000d/ngay - 7phong', '178.jpg', '', 'El Clasico cuá»‘i c&ugrave;ng cá»§a nÄƒm nay,  Ronaldo pháº§n n&agrave;o Ä‘Æ°á»£c Ä‘&aacute;nh gi&aacute;  cao  hÆ¡n sá»‘ 10 cá»§a Barca nhá» phong Ä‘á»™ á»•n  Ä‘á»‹nh trong suá»‘t thá»i gian qua.   Kh&ocirc;ng chá»‰ li&ecirc;n tiáº¿p ná»• s&uacute;ng á»Ÿ nhá»¯ng tráº­n  gáº§n Ä‘&acirc;y gi&uacute;p Real thÄƒng tiáº¿n  m', 1, 1323882000, 1, 0, 0, '178_109370631.jpg;178_74785754.jpg;178_1270266953.jpg;178_644830170.jpg;178_939003634.jpg;178_120925858.jpg'),
(179, 5, 'Deluxe', 'GÃ­a : 1000.000d/ngay - 7phong', '179.jpg', '', '<span style="color: rgb(51, 51, 51);">Ph&ograve;ng Standard cá»§a ch&uacute;ng t&ocirc;i sáº½  mang láº¡i cho qu&yacute; kh&aacute;ch kh&ocirc;ng chá»‰ chá»— á»Ÿ m&agrave; c&ograve;n l&agrave; sá»± thÆ° gi&atilde;n tuyá»‡t vá»i.  Qu&yacute; kh&aacute;ch c&oacute; thá»ƒ táº­n hÆ°á»Ÿng báº§u kh&ocirc;ng kh&iacute; y&ecirc;n tÄ©nh v&agrave; áº¥m &aacute;p táº¡i Ä‘&acirc;y. Sau  má»™t chuyáº¿n Ä‘i d&agrave;i, qu&yacute; kh&aacute;ch sáº½ kh&ocirc;ng thá»ƒ chá» Ä‘á»£i l&acirc;u th&ecirc;m ná»¯a Ä‘á»ƒ Ä‘Æ°á»£c  nghá»‰ ngÆ¡i tr&ecirc;n nhá»¯ng chiáº¿c giÆ°á»ng &ecirc;m &aacute;i, má»m máº¡i v&agrave; sáº¡ch sáº½ cá»§a ch&uacute;ng  t&ocirc;i. Ngo&agrave;i ra, c&aacute;c ph&ograve;ng Ä‘á»u Ä‘Æ°á»£c trang bá»‹ cÆ¡ sá»Ÿ váº­t cháº¥t v&agrave; trang thiáº¿t  bá»‹ hiá»‡n Ä‘áº¡i Ä‘&aacute;p á»©ng ti&ecirc;u chuáº©n quá»‘c táº¿.HÆ¡n tháº¿ ná»¯a, ch&uacute;ng t&ocirc;i cam Ä‘oan  sáº½ mang láº¡i cho qu&yacute; kh&aacute;ch h&agrave;ng má»™t kh&ocirc;ng gian sá»‘ng hiá»‡n Ä‘áº¡i, tinh táº¿ v&agrave;  h&agrave;i h&ograve;a.<br />\r\n</span><span style="color: rgb(51, 51, 51);">Ph&ograve;ng Standard cá»§a ch&uacute;ng t&ocirc;i sáº½  mang láº¡i cho qu&yacute; kh&aacute;ch kh&ocirc;ng chá»‰ chá»— á»Ÿ m&agrave; c&ograve;n l&agrave; sá»± thÆ° gi&atilde;n tuyá»‡t vá»i.  Qu&yacute; kh&aacute;ch c&oacute; thá»ƒ táº­n hÆ°á»Ÿng báº§u kh&ocirc;ng kh&iacute; y&ecirc;n tÄ©nh v&agrave; áº¥m &aacute;p táº¡i Ä‘&acirc;y. Sau  má»™t chuyáº¿n Ä‘i d&agrave;i, qu&yacute; kh&aacute;ch sáº½ kh&ocirc;ng thá»ƒ chá» Ä‘á»£i l&acirc;u th&ecirc;m ná»¯a Ä‘á»ƒ Ä‘Æ°á»£c  nghá»‰ ngÆ¡i tr&ecirc;n nhá»¯ng chiáº¿c giÆ°á»ng &ecirc;m &aacute;i, má»m máº¡i v&agrave; sáº¡ch sáº½ cá»§a ch&uacute;ng  t&ocirc;i. Ngo&agrave;i ra, c&aacute;c ph&ograve;ng Ä‘á»u Ä‘Æ°á»£c trang bá»‹ cÆ¡ sá»Ÿ váº­t cháº¥t v&agrave; trang thiáº¿t  bá»‹ hiá»‡n Ä‘áº¡i Ä‘&aacute;p á»©ng ti&ecirc;u chuáº©n quá»‘c táº¿.HÆ¡n tháº¿ ná»¯a, ch&uacute;ng t&ocirc;i cam Ä‘oan  sáº½ mang láº¡i cho qu&yacute; kh&aacute;ch h&agrave;ng má»™t kh&ocirc;ng gian sá»‘ng hiá»‡n Ä‘áº¡i, tinh táº¿ v&agrave;  h&agrave;i h&ograve;a.</span><span style="color: rgb(51, 51, 51);"><br />\r\n</span>', 1, 1323882000, 1, 0, 0, '179_100845624.jpg;179_254295818.jpg;179_899570447.jpg;179_952498239.jpg;179_230054081.jpg;179_1075848277.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tgp_cms_menu`
--

CREATE TABLE IF NOT EXISTS `tgp_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` varchar(20) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `type` int(1) DEFAULT '0',
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `rss_link` varchar(255) DEFAULT NULL,
  `rss_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tgp_cms_menu`
--

INSERT INTO `tgp_cms_menu` (`id`, `cat`, `ten`, `type`, `thu_tu`, `hien_thi`, `noi_bat`, `rss_link`, `rss_time`) VALUES
(5, 'he_thong_phong', 'Há»‡ thá»‘ng phÃ²ng', 0, 1, 1, 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_customers`
--

CREATE TABLE IF NOT EXISTS `tgp_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) NOT NULL,
  `cat` int(11) NOT NULL,
  `hinh` varchar(255) DEFAULT 'no',
  `dia_chi` varchar(255) NOT NULL,
  `gioi_thieu` text NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `dem_click` int(11) DEFAULT '0',
  `dem_view` int(11) DEFAULT '0',
  `hien_thi` int(1) NOT NULL,
  `noi_bat` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tgp_customers`
--


-- --------------------------------------------------------

--
-- Table structure for table `tgp_customers_cat`
--

CREATE TABLE IF NOT EXISTS `tgp_customers_cat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ten` varchar(255) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tgp_customers_cat`
--


-- --------------------------------------------------------

--
-- Table structure for table `tgp_doc`
--

CREATE TABLE IF NOT EXISTS `tgp_doc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `chu_thich` text NOT NULL,
  `file` varchar(255) DEFAULT 'no',
  `file_size` varchar(255) NOT NULL,
  `noi_dung` text NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `gia` double DEFAULT NULL,
  `time` int(11) NOT NULL,
  `luot_tai` int(11) NOT NULL DEFAULT '0',
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `user` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tgp_doc`
--

INSERT INTO `tgp_doc` (`id`, `cat`, `ten`, `chu_thich`, `file`, `file_size`, `noi_dung`, `hien_thi`, `gia`, `time`, `luot_tai`, `noi_bat`, `user`) VALUES
(10, 3, 'DÃ¢n trÃ­', 'http://dantri.com.vn/', 'no', '', '', 1, NULL, 1323837802, 0, 0, 1),
(11, 3, 'Mp3 zing', 'http://mp3.zing.vn/', 'no', '', '', 1, NULL, 1323837836, 0, 0, 1),
(9, 3, 'Goolge', 'http://google.com.vn/', 'no', '', '', 1, NULL, 1323837779, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_doc_menu`
--

CREATE TABLE IF NOT EXISTS `tgp_doc_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` varchar(20) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tgp_doc_menu`
--

INSERT INTO `tgp_doc_menu` (`id`, `cat`, `ten`, `thu_tu`, `hien_thi`) VALUES
(3, 'lien_ket', 'Website liÃªn káº¿t', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_email`
--

CREATE TABLE IF NOT EXISTS `tgp_email` (
  `email` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tgp_email`
--

INSERT INTO `tgp_email` (`email`, `time`) VALUES
('thienbaoit@gmail.com', 1323837207);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_gallery`
--

CREATE TABLE IF NOT EXISTS `tgp_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `chu_thich` text NOT NULL,
  `hinh` varchar(255) DEFAULT 'no',
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `noi_bat` int(1) NOT NULL DEFAULT '1',
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL DEFAULT '0',
  `luot_xem` int(11) NOT NULL DEFAULT '0',
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tgp_gallery`
--

INSERT INTO `tgp_gallery` (`id`, `cat`, `ten`, `chu_thich`, `hinh`, `hien_thi`, `noi_bat`, `time`, `user`, `luot_xem`, `link`) VALUES
(19, 28, 'hinh1', '', '19.jpg', 1, 0, 1323657959, 1, 0, ''),
(20, 28, 'hinh2', '', '20.jpg', 1, 0, 1323657974, 1, 0, ''),
(21, 28, 'hinh3', '', '21.jpg', 1, 0, 1323657994, 1, 0, ''),
(22, 28, 'hinh4', '', '22.jpg', 1, 0, 1323658005, 1, 0, ''),
(40, 34, 'hinh1', '', '40.jpg', 1, 0, 1328233179, 1, 0, ''),
(41, 34, 'hinh2', '', '41.jpg', 1, 0, 1328233206, 1, 0, ''),
(42, 34, 'hinh3', '', '42.jpg', 1, 0, 1328233222, 1, 0, ''),
(43, 29, 'hinh1', '', '43.jpg', 1, 0, 1328256640, 1, 0, ''),
(44, 29, 'hinh2', '', '44.jpg', 1, 0, 1328256698, 1, 0, ''),
(45, 35, 'hinh22', '', '45.jpg', 1, 0, 1328256717, 1, 0, ''),
(46, 36, 'hinh13', '', '46.jpg', 1, 0, 1328256736, 1, 0, ''),
(47, 29, 'hinh13', '', '47.jpg', 1, 0, 1328257653, 1, 0, ''),
(48, 29, 'hinh15', '', '48.jpg', 1, 0, 1328257676, 1, 0, ''),
(49, 29, 'hinh156', '', '49.jpg', 1, 0, 1328257696, 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `tgp_gallery_menu`
--

CREATE TABLE IF NOT EXISTS `tgp_gallery_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` varchar(20) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tgp_gallery_menu`
--

INSERT INTO `tgp_gallery_menu` (`id`, `cat`, `ten`, `thu_tu`, `hien_thi`) VALUES
(28, 'slide_background', 'Slide background full', 1, 1),
(29, 'thu_vien_hinh', 'album 1', 1, 1),
(36, 'thu_vien_hinh', 'ablum 3', 3, 1),
(34, 'gioi_thieu', 'Giá»›i thiá»‡u', 1, 1),
(35, 'thu_vien_hinh', 'ablum 2', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_online`
--

CREATE TABLE IF NOT EXISTS `tgp_online` (
  `ip` varchar(255) NOT NULL DEFAULT '',
  `time` varchar(255) NOT NULL DEFAULT '',
  `site` varchar(255) NOT NULL DEFAULT '',
  `agent` varchar(255) NOT NULL DEFAULT '',
  `user` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tgp_online`
--

INSERT INTO `tgp_online` (`ip`, `time`, `site`, `agent`, `user`) VALUES
('127.0.0.1', '1328497076', '', 'Mozilla/5.0 (Windows NT 6.1; rv:10.0) Gecko/20100101 Firefox/10.0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_online_daily`
--

CREATE TABLE IF NOT EXISTS `tgp_online_daily` (
  `ngay` varchar(10) NOT NULL DEFAULT '',
  `bo_dem` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ngay`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tgp_online_daily`
--

INSERT INTO `tgp_online_daily` (`ngay`, `bo_dem`) VALUES
('27/07/2010', 7),
('28/07/2010', 17),
('02/08/2010', 2),
('03/08/2010', 6),
('04/08/2010', 14),
('05/08/2010', 13),
('06/08/2010', 10),
('07/08/2010', 5),
('09/08/2010', 15),
('10/08/2010', 1),
('11/08/2010', 2),
('12/08/2010', 18),
('13/08/2010', 21),
('14/08/2010', 17),
('16/08/2010', 1),
('20/08/2010', 1),
('21/08/2010', 4),
('23/08/2010', 8),
('24/08/2010', 5),
('01/09/2010', 2),
('03/09/2010', 7),
('04/09/2010', 4),
('06/09/2010', 4),
('08/09/2010', 1),
('10/09/2010', 4),
('11/09/2010', 7),
('13/09/2010', 12),
('14/09/2010', 7),
('15/09/2010', 13),
('16/09/2010', 18),
('17/09/2010', 15),
('18/09/2010', 7),
('19/09/2010', 3),
('20/09/2010', 9),
('21/09/2010', 9),
('22/09/2010', 16),
('23/09/2010', 9),
('24/09/2010', 25),
('25/09/2010', 17),
('26/09/2010', 16),
('27/09/2010', 33),
('28/09/2010', 59),
('29/09/2010', 65),
('30/09/2010', 71),
('01/10/2010', 13),
('02/10/2010', 12),
('04/10/2010', 10),
('05/10/2010', 11),
('06/10/2010', 9),
('07/10/2010', 10),
('08/10/2010', 7),
('09/10/2010', 5),
('10/10/2010', 1),
('11/10/2010', 8),
('12/10/2010', 19),
('13/10/2010', 19),
('14/10/2010', 12),
('15/10/2010', 29),
('16/10/2010', 20),
('18/10/2010', 6),
('19/10/2010', 1),
('20/10/2010', 10),
('21/10/2010', 12),
('22/10/2010', 3),
('23/10/2010', 4),
('25/10/2010', 4),
('29/10/2010', 4),
('03/10/2011', 12),
('04/10/2011', 8),
('05/10/2011', 14),
('06/10/2011', 7),
('13/10/2011', 3),
('14/10/2011', 2),
('15/10/2011', 7),
('12/12/2011', 11),
('13/12/2011', 12),
('14/12/2011', 5),
('15/12/2011', 4),
('16/12/2011', 7),
('17/12/2011', 2),
('19/12/2011', 3),
('23/12/2011', 7),
('26/12/2011', 4),
('29/12/2011', 1),
('08/01/2012', 2),
('13/01/2012', 2),
('02/02/2012', 8),
('03/02/2012', 9),
('04/02/2012', 4),
('05/02/2012', 2),
('06/02/2012', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_page`
--

CREATE TABLE IF NOT EXISTS `tgp_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alias` varchar(255) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `noi_dung` text NOT NULL,
  `time` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `luot_xem` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=72 ;

--
-- Dumping data for table `tgp_page`
--

INSERT INTO `tgp_page` (`id`, `alias`, `ten`, `noi_dung`, `time`, `user`, `luot_xem`) VALUES
(57, 'copyright', 'Copyright', '<span style="color: rgb(246, 222, 145);"><span style="font-weight: bold;">EDENHOTEL</span><br />\r\nÄá»‹a chá»‰: Sá»‘ Duy T&acirc;n -&nbsp; Q. Háº£i Ch&acirc;u - TP. Ä&agrave; Náºµng<br />\r\nÄiá»‡n thoáº¡i : (0511) 3368368&nbsp; Fax: (0511) 3368368<br />\r\nEmail : info@edenhotel.vn</span>', 1328364880, 1, 5794),
(55, 'thong_tin_lien_he', 'ThÃ´ng tin liÃªn há»‡', 'Má»i tháº¯c máº¯c v&agrave; g&oacute;p &yacute;, xin vui l&ograve;ng li&ecirc;n há»‡ theo form sau, xin c&aacute;m Æ¡n :<br />', 1328243331, 1, 871),
(65, 'dich_vu', 'dich vu ', '<div style="line-height:20px;width:279px;" dir="ltr">\r\n<ul>\r\n    <li><font size="2">Ph&ograve;ng kh&aacute;ch sáº¡n&nbsp;</font></li>\r\n    <li><font size="2">Thu&ecirc; há»™i trÆ°á»ng</font></li>\r\n    <li><font size="2">Li&ecirc;n hoan - Gáº·p máº·t&nbsp;</font></li>\r\n    <li><font size="2">Tá»• chá»©c Há»™i nghá»‹ - Há»™i tháº£o</font></li>\r\n    <li><font size="2">Thu&ecirc; &ocirc; t&ocirc; - Xe m&aacute;y - Xe Ä‘áº¡p<br />\r\n    </font></li>\r\n    <li><font size="2"> </font><font size="2">Tour v&ograve;ng quanh b&aacute;n Ä‘áº£o SÆ¡n Tr&agrave;<br />\r\n    </font></li>\r\n    <li><font size="2"> Tour c&acirc;u c&aacute;&nbsp;Ä‘&ecirc;m tr&ecirc;n b&aacute;n&nbsp;Ä‘áº£o SÆ¡n Tr&agrave;<br />\r\n    </font></li>\r\n    <li><font size="2"> Tour Non NÆ°á»›c - Há»™i An - Má»¹ SÆ¡n<br />\r\n    </font></li>\r\n    <li><font size="2"> </font><font size="2">Tour B&agrave; N&agrave;</font></li>\r\n</ul>\r\n</div>', 1328253785, 1, 529),
(68, 'ho_tro', 'Há»— trá»£', '<table cellspacing="0" cellpadding="0" border="0" align="left" width="230px">\r\n    <tbody>\r\n        <tr>\r\n            <td><a href="ymsgr:sendim?noh4ndsom3"><strong><img height="23" border="0" align="absMiddle" width="30" vspace="4" src="/uploads/image/yahoo.png" alt="" /><br />\r\n            </strong></a></td>\r\n            <td><span><span style="width: 78px; float: left;"><br />\r\n            &nbsp;&nbsp;&nbsp;             Ms. Dung<br />\r\n            0126 .368836</span><strong><span style="width: 78px; float: left;"> &nbsp;&nbsp; <br />\r\n            </span></strong></span></td>\r\n            <td width="20px">&nbsp;</td>\r\n            <td width="20px">&nbsp;</td>\r\n            <td><a href="ymsgr:sendim?noh4ndsom3"><img height="20" border="0" align="absMiddle" width="40" vspace="4" src="/uploads/image/skyle.png" alt="" /><br />\r\n            </a></td>\r\n            <td><span width:="" float:=""><br />\r\n            &nbsp; &nbsp; &nbsp; Mr. Hai<br />\r\n            0909 090909</span><strong><span style="color: rgb(61, 69, 8); width: 78px; float: left;"><span style="color: rgb(61, 69, 8);">&nbsp;&nbsp;&nbsp;</span>&nbsp; <br />\r\n            </span></strong></td>\r\n        </tr>\r\n    </tbody>\r\n</table>', 1324095410, 1, 3637),
(70, 'gioi_thieu', 'Giá»›i thiá»‡u', 'Real Ä‘&atilde; kh&ocirc;ng   Ä‘Æ°á»£c Ä‘&aacute;p láº¡i nhÆ°ng kh&ocirc;ng thá»ƒ phá»§ nháº­n nhá»¯ng ná»— lá»±c v&agrave; th&agrave;nh c&ocirc;ng nháº¥t   Ä‘á»‹nh vá» máº·t tháº¿ tráº­n cá»§a Ä‘á»™i chá»§ nh&agrave;. 45 ph&uacute;t Ä‘áº§u ti&ecirc;n l&agrave; khoáº£ng thá»i   gian m&agrave; cá»— m&aacute;y cá»§Kh&ocirc;ng thá»«a khi ngÆ°á»i ta d&agrave;nh sá»± ngá»£i ca   v&agrave; t&aacute;n dÆ°Æ¡ng cho báº£n lÄ©nh cá»§a Barca á»Ÿ tráº­n El Clasico. NhÆ°ng c&oacute; váº» nhÆ°   táº¥t cáº£ Ä‘&atilde; Real Ä‘&atilde; kh&ocirc;ng   Ä‘Æ°á»£c Ä‘&aacute;p láº¡i nhÆ°ng kh&ocirc;ng thá»ƒ phá»§ nháº­n nhá»¯ng ná»— lá»±c v&agrave; th&agrave;nh c&ocirc;ng nháº¥t   Ä‘á»‹nh vá» máº·t tháº¿ tráº­n cá»§a Ä‘á»™i chá»§ nh&agrave;. 45 ph&uacute;t Ä‘áº§u ti&ecirc;n l&agrave; khoáº£ng thá»i   gian m&agrave; cá»— m&aacute;y cá»§Kh&ocirc;ng thá»«a khi ngÆ°á»i ta d&agrave;nh sá»± ngá»£i ca   v&agrave; t&aacute;n dÆ°Æ¡ng cho báº£n lÄ©nh cá»§a Barca á»Ÿ tráº­n El Clasico. NhÆ°ng c&oacute; váº» nhÆ°   táº¥t cáº£ Ä‘&atilde; Real Ä‘&atilde; kh&ocirc;ng   Ä‘Æ°á»£c Ä‘&aacute;p láº¡i nhÆ°ng kh&ocirc;ng thá»ƒ phá»§ nháº­n nhá»¯ng ná»— lá»±c v&agrave; th&agrave;nh c&ocirc;ng nháº¥t   Ä‘á»‹nh vá» máº·t tháº¿ tráº­n cá»§a Ä‘á»™i chá»§ nh&agrave;. 45 ph&uacute;t Ä‘áº§u ti&ecirc;n l&agrave; khoáº£ng thá»i   gian m&agrave; cá»— m&aacute;y cá»§Kh&ocirc;ng thá»«a khi ngÆ°á»i ta d&agrave;nh sá»± ngá»£i ca   v&agrave; t&aacute;n dÆ°Æ¡ng cho báº£n lÄ©nh cá»§a Barca á»Ÿ tráº­n El Clasico. NhÆ°ng c&oacute; váº» nhÆ°   táº¥t cáº£ Ä‘&atilde; Real Ä‘&atilde; kh&ocirc;ng   Ä‘Æ°á»£c Ä‘&aacute;p láº¡i nhÆ°ng kh&ocirc;ng thá»ƒ phá»§ nháº­n nhá»¯ng ná»— lá»±c v&agrave; th&agrave;nh c&ocirc;ng nháº¥t   Ä‘á»‹nh vá» máº·t tháº¿ tráº­n cá»§a Ä‘á»™i chá»§ nh&agrave;. 45 ph&uacute;t Ä‘áº§u ti&ecirc;n l&agrave; khoáº£ng thá»i   gian m&agrave; cá»— m&aacute;y cá»§Kh&ocirc;ng thá»«a khi ngÆ°á»i ta d&agrave;nh sá»± ngá»£i ca   v&agrave; t&aacute;n dÆ°Æ¡ng cho báº£n lÄ©nh cá»§a Barca á»Ÿ tráº­n El Clasico. NhÆ°ng c&oacute; váº» nhÆ°   táº¥t cáº£ Ä‘&atilde; Real Ä‘&atilde; kh&ocirc;ng   Ä‘Æ°á»£c Ä‘&aacute;p láº¡i nhÆ°ng kh&ocirc;ng thá»ƒ phá»§ nháº­n nhá»¯ng ná»— lá»±c v&agrave; th&agrave;nh c&ocirc;ng nháº¥t   Ä‘á»‹nh vá» máº·t tháº¿ tráº­n cá»§a Ä‘á»™i chá»§ nh&agrave;. 45 ph&uacute;t Ä‘áº§u ti&ecirc;n l&agrave; khoáº£ng thá»i   gian m&agrave; cá»— m&aacute;y cá»§Kh&ocirc;ng thá»«a khi ngÆ°á»i ta d&agrave;nh sá»± ngá»£i ca   v&agrave; t&aacute;n dÆ°Æ¡ng cho báº£n lÄ©nh cá»§a Barca á»Ÿ tráº­n El Clasico. NhÆ°ng c&oacute; váº» nhÆ°   táº¥t cáº£ Ä‘&atilde;', 1324268742, 1, 1),
(71, 'lien_he_dat_phong', 'LiÃªn há»‡ Ä‘áº·t phÃ²ng', 'Qu&yacute; kh&aacute;ch vui l&ograve;ng Ä‘iá»n v&agrave;o &ocirc; trá»‘ng dÆ°á»›i Ä‘&acirc;y Ä‘á»ƒ Ä‘áº·t ph&ograve;ng hoáº·c gá»i 05113.967.666 - 05113.967.665. C&aacute;m Æ¡n qu&yacute; kh&aacute;ch Ä‘&atilde; li&ecirc;n há»‡ vá»›i ch&uacute;ng t&ocirc;i.<br />', 1328241700, 1, 334);

-- --------------------------------------------------------

--
-- Table structure for table `tgp_product`
--

CREATE TABLE IF NOT EXISTS `tgp_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` int(11) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `chu_thich` text NOT NULL,
  `hinh` varchar(255) DEFAULT 'no',
  `noi_dung` text NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  `gia` double DEFAULT NULL,
  `don_vi` int(1) DEFAULT '0',
  `time` int(11) NOT NULL,
  `luot_xem` int(11) NOT NULL DEFAULT '0',
  `noi_bat` int(1) NOT NULL DEFAULT '0',
  `user` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `tgp_product`
--


-- --------------------------------------------------------

--
-- Table structure for table `tgp_product_menu`
--

CREATE TABLE IF NOT EXISTS `tgp_product_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat` varchar(20) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `thu_tu` int(11) NOT NULL,
  `hien_thi` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `tgp_product_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `tgp_user`
--

CREATE TABLE IF NOT EXISTS `tgp_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL DEFAULT '',
  `password` varchar(32) DEFAULT 'no',
  `ten` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `dien_thoai` varchar(20) NOT NULL DEFAULT '',
  `dia_chi` varchar(255) NOT NULL DEFAULT '',
  `level` int(1) DEFAULT '0',
  `trang_thai` int(1) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tgp_user`
--

INSERT INTO `tgp_user` (`id`, `username`, `password`, `ten`, `email`, `dien_thoai`, `dia_chi`, `level`, `trang_thai`, `time`) VALUES
(1, 'admin', 'b9d11b3be25f5a1a7dc8ca04cd310b28', 'Dang Thien Bao', 'thienbaoit@gmail.com', '0126.3688368', 'http://goon.net/', 0, 1, 0);
